#include <stdio.h>

#include "video.h"

void init_video() {
	printf("init_video\n");
}
