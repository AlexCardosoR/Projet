#ifndef EDITEUR_H
#define EDITEUR_H

typedef struct {
	int version;
} Editeur;

#endif

